import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class Tri {
    public static int entierPourChaineTrier(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        // retourne l'entier associé à chaine si elle est présente dans listePaires, sinon 0
        int i = 0;
        while (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) < 0) {
            i++;
        }
        if (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) == 0) {
            return listePaires.get(i).getEntier();
        } else {
            return 0;
        }
    }
    public static int scoreLexiqueTrie(Depeche depeche, Categorie categorie) {
        int score = 0;
        int indiceDepeche = 0;
        while (indiceDepeche < depeche.getMots().size()) {
            // on parcourt les mots de la dépêche
            score += Tri.entierPourChaineTrier(categorie.getLexique(), depeche.getMots().get(indiceDepeche));
            indiceDepeche++;
        }
        return score;
    }

    public static ArrayList<PaireChaineEntier> initDicoTrie(ArrayList<Depeche> depeches, String categorie) {
        // récupère le lexique d'une catégorie dans le vecteur de depeche et l'insère
        // dans un dictionnaire de manière à ce qu'il soit trié
        // on parcours toutes les dépêches
        int indiceDepeche = 0;
        ArrayList<PaireChaineEntier> dictionnaire = new ArrayList<>();
        while (indiceDepeche < depeches.size()) {
            // on teste si la depêche fait parti de categorie
            Depeche depeche = depeches.get(indiceDepeche);
            if (depeche.getCategorie().compareTo(categorie) == 0) {
                // si dépêche fait parti de catégorie, on ajoute ses mots dans le tableau
                int indiceMots = 0;
                while (indiceMots < depeche.getMots().size()) {
                    // on insère les mots un par un dans resultat s'il n'y sont pas déjà
                    PaireChaineEntier mot = new PaireChaineEntier(depeche.getMots().get(indiceMots), 0);
                    // si le mot a moins de 3 caractères, il est considéré comme inutile
                    if (mot.getChaine().length() > 3) {
                        int indiceDico = 0;
                        // on parcours le dictionnaire tant que le mot courant est plus petit que celui à insérer
                        while (indiceDico < dictionnaire.size() && dictionnaire.get(indiceDico).compareTo(mot) < 0) {
                            indiceDico++;
                        }
                        // on teste si le mot courant est plus grand que celui à insérer
                        // sous entendu le mot courant n'est pas égale à celui à insérer
                        if (indiceDico < dictionnaire.size() && dictionnaire.get(indiceDico).compareTo(mot) > 0) {
                            dictionnaire.add(indiceDico, mot);
                            // on teste si la position à laquelle doit se trouver le mot est égale à dictionnaire.size()
                            // sous entendu le mot doit être à la fin du dictionnaire
                        } else if (indiceDico == dictionnaire.size()) {
                            dictionnaire.add(mot);
                        }
                    }
                    indiceMots++;
                }
            }
            indiceDepeche++;
        }
        return dictionnaire;
    }

    public static void calculScoresTrie(ArrayList<Depeche> depeches, String categorie, ArrayList<PaireChaineEntier> dictionnaire) {
        // on parcours toutes les dépêches
        int indiceDepeche = 0;
        while (indiceDepeche < depeches.size()) {
            // on parcours les mots de la dépêche
            Depeche depeche = depeches.get(indiceDepeche);
            int indiceMots = 0;
            while (indiceMots < depeche.getMots().size()) {
                int indiceResultat = 0;
                String mot = depeche.getMots().get(indiceMots);
                while (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mot) < 0) {
                    indiceResultat++;
                }
                if (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mot) == 0 && depeche.getCategorie().compareTo(categorie) == 0) {
                    dictionnaire.get(indiceResultat).incrementeEntier(1);
                } else if (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mot) == 0 && depeche.getCategorie().compareTo(categorie) != 0) {
                    dictionnaire.get(indiceResultat).incrementeEntier(-1);
                }
                indiceMots++;
            }
            indiceDepeche++;
        }
    }

    public static void generationLexiqueTrie(ArrayList<Depeche> depeches, String categorie, String nomFichier) {
        // on initialise tous les mots contenus dans les depeches de types categories
        ArrayList<PaireChaineEntier> dictionnaire = initDicoTrie(depeches, categorie);
        // on calcule le score de tous les mots contenus dans les depeches de types categories en fonction de toutes les depeches
        calculScoresTrie(depeches, categorie, dictionnaire);
        // on parcours tout le lexique d'une catégorie pour modifier son score et l'écrire dans le fichier nomFichier
        try {
            int indiceDico = 0;
            FileWriter newFile = new FileWriter(nomFichier);
            while (indiceDico < dictionnaire.size()) {
                dictionnaire.get(indiceDico).setEntier(Classification.poidsPourScore(dictionnaire.get(indiceDico).getEntier()));
                if (dictionnaire.get(indiceDico).getEntier() > 0) {
                    newFile.write(dictionnaire.get(indiceDico).getChaine() + ":" + dictionnaire.get(indiceDico).getEntier() + "\n");
                }
                indiceDico++;
            }
            newFile.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public static void classementDepechesTrie(ArrayList<Depeche> depeches, ArrayList<Categorie> categories, String nomFichier) {
        int indiceDepeche = 0;      // on initialise i pour parcourir le tableau de dépêche
        // on créé un tableau qui contiendra le nombre de bonne réponse pour chaque catégorie
        ArrayList<PaireChaineEntier> resultat = new ArrayList<>(Arrays.asList(
                new PaireChaineEntier("ENVIRONNEMENT-SCIENCES", 0),
                new PaireChaineEntier("CULTURE", 0),
                new PaireChaineEntier("ECONOMIE", 0),
                new PaireChaineEntier("POLITIQUE", 0),
                new PaireChaineEntier("SPORTS", 0)));
        // on parcourt toutes les dépêches
        try {
            FileWriter newFile = new FileWriter(nomFichier);
            while (indiceDepeche < depeches.size()) {
                // on créé un tableau de score pour chaque dépêches
                ArrayList<PaireChaineEntier> VScore = new ArrayList<>();
                int indiceCategorie = 0;
                // on calcule le score de la dépêche pour chaque catégories et on l'ajoute au tableau de score
                while (indiceCategorie < categories.size()) {
                    VScore.add(new PaireChaineEntier(categories.get(indiceCategorie).getNom(), scoreLexiqueTrie(depeches.get(indiceDepeche), categories.get(indiceCategorie))));
                    indiceCategorie++;
                }
                // on determine la catégorie qui a le plus de points
                String categorie = UtilitairePaireChaineEntier.chaineMax(VScore);
                // on ajoute une bonne réponse à la catégorie dans le tableau résultat
                if (categorie.compareTo(depeches.get(indiceDepeche).getCategorie()) == 0) {
                    resultat.get(UtilitairePaireChaineEntier.indicePourChaine(resultat, categorie)).incrementeEntier(1);
                }
                // on écrit dans le fichier la catégorie trouvé de la dépêche
                newFile.write(depeches.get(indiceDepeche).getId() + ":" + categorie + "\n");
                indiceDepeche++;
            }
            newFile.write("ENVIRONNEMENT-SCIENCES : " + resultat.get(0).getEntier() + "%\n" +
                    "CULTURE : " + resultat.get(1).getEntier() + "%\n" +
                    "ECONOMIE : " + resultat.get(2).getEntier() + "%\n" +
                    "POLITIQUE : " + resultat.get(3).getEntier() + "%\n" +
                    "SPORTS : " + resultat.get(4).getEntier() + "%\n" +
                    "MOYENNE : " + UtilitairePaireChaineEntier.moyenne(resultat) + "%\n");
            newFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

