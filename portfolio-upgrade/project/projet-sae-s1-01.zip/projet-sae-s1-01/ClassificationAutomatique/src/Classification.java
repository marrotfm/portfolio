import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Arrays;

public class Classification {


    public static ArrayList<Depeche> lectureDepeches(String nomFichier) {
        //creation d'un tableau de dépêches
        ArrayList<Depeche> depeches = new ArrayList<>();
        try {
            // lecture du fichier d'entrée
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);

            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                String id = ligne.substring(3);
                ligne = scanner.nextLine();
                String date = ligne.substring(3);
                ligne = scanner.nextLine();
                String categorie = ligne.substring(3);
                ligne = scanner.nextLine();
                String lignes = ligne.substring(3);
                while (scanner.hasNextLine() && !ligne.equals("")) {
                    ligne = scanner.nextLine();
                    if (!ligne.equals("")) {
                        lignes = lignes + '\n' + ligne;
                    }
                }
                Depeche uneDepeche = new Depeche(id, date, categorie, lignes);
                depeches.add(uneDepeche);
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return depeches;
    }


    public static void classementDepeches(ArrayList<Depeche> depeches, ArrayList<Categorie> categories, String nomFichier) {
        int indiceDepeche = 0;      // on initialise i pour parcourir le tableau de dépêche
        // on créé un tableau qui contiendra le nombre de bonne réponse pour chaque catégorie
        ArrayList<PaireChaineEntier> resultat = new ArrayList<>(Arrays.asList(
                new PaireChaineEntier("ENVIRONNEMENT-SCIENCES", 0),
                new PaireChaineEntier("CULTURE", 0),
                new PaireChaineEntier("ECONOMIE", 0),
                new PaireChaineEntier("POLITIQUE", 0),
                new PaireChaineEntier("SPORTS", 0)));
        // on parcourt toutes les dépêches
        try {
            FileWriter newFile = new FileWriter(nomFichier);
            while (indiceDepeche < depeches.size()) {
                // on créé un tableau de score pour chaque dépêches
                ArrayList<PaireChaineEntier> VScore = new ArrayList<>();
                int j = 0;
                // on calcule le score de la dépêche pour chaque catégories et on l'ajoute au tableau de score
                while (j < categories.size()) {
                    VScore.add(new PaireChaineEntier(categories.get(j).getNom(), categories.get(j).score(depeches.get(indiceDepeche))));
                    j++;
                }
                // on determine la catégorie qui a le plus de points
                String categorie = UtilitairePaireChaineEntier.chaineMax(VScore);
                // on ajoute une bonne réponse à la catégorie dans le tableau résultat
                if (categorie.compareTo(depeches.get(indiceDepeche).getCategorie()) == 0) {
                    resultat.get(UtilitairePaireChaineEntier.indicePourChaine(resultat, categorie)).incrementeEntier(1);
                }
                // on écrit dans le fichier la catégorie trouvé de la dépêche
                newFile.write(depeches.get(indiceDepeche).getId() + ":" + categorie  + "\n");
                indiceDepeche++;
            }
            newFile.write("ENVIRONNEMENT-SCIENCES : " + resultat.get(0).getEntier()+ "%\n" +
                    "CULTURE : " + resultat.get(1).getEntier() + "%\n" +
                    "ECONOMIE : " + resultat.get(2).getEntier() + "%\n" +
                    "POLITIQUE : " + resultat.get(3).getEntier() + "%\n" +
                    "SPORTS : " + resultat.get(4).getEntier() + "%\n" +
                    "MOYENNE : " + UtilitairePaireChaineEntier.moyenne(resultat) + "%\n");
            newFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static ArrayList<PaireChaineEntier> initDico(ArrayList<Depeche> depeches, String categorie) {
        // on parcours toutes les dépêches
        int indiceDepeche = 0;
        ArrayList<PaireChaineEntier> dictionnaire = new ArrayList<>();
        while (indiceDepeche < depeches.size()) {
            // on teste si la depêche fait parti de categorie
            Depeche depeche = depeches.get(indiceDepeche);
            if (depeche.getCategorie().compareTo(categorie) == 0) {
                // si dépêche fait parti de catégorie, on ajoute ses mots dans le tableau
                int indiceMots = 0;
                while (indiceMots < depeche.getMots().size()) {
                    // on insère les mots un par un dans resultat s'il n'y sont pas déjà
                    String mots = depeche.getMots().get(indiceMots);

                    if (mots.length() > 3) {
                        int indiceResultat = 0;
                        while (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mots) != 0) {
                            indiceResultat++;
                        }
                        if ( indiceResultat == dictionnaire.size()) {
                            dictionnaire.add(new PaireChaineEntier(mots, 0));
                        }
                    }
                    indiceMots++;
                }
            }
            indiceDepeche++;
        }
        return dictionnaire;
    }

    public static void calculScores(ArrayList<Depeche> depeches, String categorie, ArrayList<PaireChaineEntier> dictionnaire) {
        // on parcours toutes les dépêches
        int indiceDepeche = 0;
        while (indiceDepeche < depeches.size()) {
            // on parcours les mots de la dépêche
            Depeche depeche = depeches.get(indiceDepeche);
            int indiceMots = 0;
            while (indiceMots < depeche.getMots().size()) {
                // on insère les mots un par un dans resultat s'il n'y sont pas déjà
                int indiceResultat = 0;
                String mots = depeche.getMots().get(indiceMots);
                while (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mots) != 0) {
                    indiceResultat++;
                }
                if (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mots) == 0 && depeche.getCategorie().compareTo(categorie) == 0) {
                    dictionnaire.get(indiceResultat).incrementeEntier(1);
                } else if (indiceResultat < dictionnaire.size() && dictionnaire.get(indiceResultat).getChaine().compareTo(mots) == 0 && depeche.getCategorie().compareTo(categorie) != 0) {
                    dictionnaire.get(indiceResultat).incrementeEntier(-1);
                }
                indiceMots++;
            }
            indiceDepeche++;
        }
    }

    public static int poidsPourScore(int score) {
        if (score < 0) {
            return 0;
        } else if (score < 1) {
            return 1;
        } else if (score < 2) {
            return 2;
        } else {
            return 3;
        }

    }

    public static void generationLexique(ArrayList<Depeche> depeches, String categorie, String nomFichier) {
        // on initialise tous les mots contenus dans les depeches de types categories
        ArrayList<PaireChaineEntier> dictionnaire = initDico(depeches, categorie);
        // on calcule le score de tous les mots contenus dans les depeches de types categories en fonction de toutes les depeches
        calculScores(depeches, categorie, dictionnaire);
        // on parcours tout le lexique d'une catégorie pour modifier son score et l'écrire dans le fichier nomFichier
        try {
            int indiceDico = 0;
            FileWriter newFile = new FileWriter(nomFichier);
            while (indiceDico < dictionnaire.size()) {
                dictionnaire.get(indiceDico).setEntier(poidsPourScore(dictionnaire.get(indiceDico).getEntier()));
                if (dictionnaire.get(indiceDico).getEntier() > 0) {
                    newFile.write(dictionnaire.get(indiceDico).getChaine() + ":" + dictionnaire.get(indiceDico).getEntier() + "\n");
                }
                indiceDico++;
            }
            newFile.close();
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    public static void main(String[] args) {

        Menu.principal();

    }
}
