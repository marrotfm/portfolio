import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Categorie {

    private final String nom; // le nom de la catégorie p.ex : sport, politique,...
    private ArrayList<PaireChaineEntier> lexique; //le lexique de la catégorie

    // constructeur
    public Categorie(String nom, String nomFichier) {
        this.nom = nom;
        initLexique(nomFichier);
    }
    public Categorie(String nom) {
        this.nom = nom;
    }


    public String getNom() {
        return nom;
    }


    public  ArrayList<PaireChaineEntier> getLexique() {
        return lexique;
    }


    // initialisation du lexique de la catégorie à partir du contenu d'un fichier texte
    public void initLexique(String nomFichier) {
        lexique = new ArrayList<>();
        try {
            FileInputStream file = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                int index = ligne.lastIndexOf(":");
                String chaine = ligne.substring(0,index);
                int entier = Integer.parseInt(ligne.substring(index+1));
                lexique.add(new PaireChaineEntier(chaine, entier));
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //calcul du score d'une dépêche pour la catégorie
    public int score(Depeche d) {
        int score = 0;
        int indiceDepeche = 0;
        while (indiceDepeche < d.getMots().size()) {
            // on parcourt les mots de la dépêche
            score += UtilitairePaireChaineEntier.entierPourChaine(lexique, d.getMots().get(indiceDepeche));
            indiceDepeche++;
        }
        return score;
    }

}

