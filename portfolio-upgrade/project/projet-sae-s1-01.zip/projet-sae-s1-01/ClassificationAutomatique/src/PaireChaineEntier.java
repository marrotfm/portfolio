public class PaireChaineEntier implements Comparable<PaireChaineEntier> {
    private String chaine;
    private int entier;

    public PaireChaineEntier(String chaine, int entier) {
        this.chaine = chaine;
        this.entier = entier;
    }

    public void incrementeEntier(int val) {
        this.entier += val;
    }

    public void setEntier(int val) {
        this.entier = val;
    }

    public String getChaine() {
        return chaine;
    }

    public int getEntier() {
        return entier;
    }

    @Override
    public int compareTo(PaireChaineEntier o) {
        if (this.chaine.compareTo(o.getChaine()) < 0 | (this.chaine.compareTo(o.getChaine()) == 0 && this.entier < o.getEntier())) {
            return -1;
        } else if (this.chaine.compareTo(o.getChaine()) == 0 && this.entier == o.getEntier()) {
            return 0;
        } else {
            return 1;
        }
    }
}
