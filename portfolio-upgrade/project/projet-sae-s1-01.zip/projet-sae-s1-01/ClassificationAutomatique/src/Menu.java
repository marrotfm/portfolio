import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
public class Menu {
    public static void principal() {
        System.out.println("Bienvenue sur notre programme:");
        menu();
    }
    private static void menu() {
        System.out.println(" ----------------------------------------------------");
        System.out.println(" 1 - Partie 1: Question 5.2 - c --> Test méthode Categorie.initLexique()");
        System.out.println(" 2 - Partie 1: Question 5.2 - e --> Test méthode UtilitairePourChaineEntier.entierPourChaine()");
        System.out.println(" 3 - Partie 1: Question 5.3 - b --> Test méthode Categorie.score");
        System.out.println(" 4 - Partie 1: Question 5.4 - b --> Test méthode UtilitairePaireChaineEntier.chaineMax()");
        System.out.println(" 5 - Partie 1: Question 5.5 - b --> Test méthode Classification.classementDepeche()");
        System.out.println(" 6 - Partie 2: Question 3.4 - b --> Test méthode Classification.generationLexique()");
        System.out.println(" 7 - Partie 2: Question 3.5 --> Test programme entier");
        System.out.println(" 8 - Partie 2: Question 3.5 --> Prise en charge de flux RSS ");
        System.out.println(" 9 - Partie 2: Question 3.6 --> Amélioration du temps de traitement ");
        System.out.println(" 10 - QUITTER LE PROGRAMME");
        System.out.println(" ----------------------------------------------------");
        System.out.print("Ceci est un menu: saisissez le numéro de la question pour y accéder: ");
        Scanner lecteur = new Scanner(System.in);
        int saisi = lecteur.nextInt();
        lecteur.nextLine();
        System.out.println();
        if (saisi == 1) {
            question1();
            System.out.println();
            menu();
        } else if (saisi == 2) {
            question2();
            System.out.println();
            menu();
        } else if (saisi == 3)  {
            question3();
            System.out.println();
            menu();
        } else if (saisi == 4) {
            question4();
            System.out.println();
            menu();
        } else if (saisi == 5) {
            question5();
            System.out.println();
            menu();
        } else if (saisi == 6) {
            question6();
            System.out.println();
            menu();
        } else if (saisi == 7) {
            question7();
            System.out.println();
            menu();
        } else if (saisi == 8) {
            question8();
            System.out.println();
            menu();
        } else if (saisi == 9) {
            question9();
            System.out.println();
            menu();
        } else if (saisi == 10) {
            System.out.println("À la prochaine :p");
        } else {
            menu();
        }
    }
    public static void question1() {
        System.out.println("Test méthode Categorie.initLexique()");
        Categorie environnementSciences = new Categorie("environnement-science");
        environnementSciences.initLexique("environnement-sciences.txt");
        int i = 0;
        while (i < environnementSciences.getLexique().size()) {
            System.out.println(environnementSciences.getLexique().get(i).getChaine() + " : " + environnementSciences.getLexique().get(i).getEntier());
            i++;
        }
    }

    public static void question2() {
        System.out.println("Test méthode UtilitairePaireChaineEntier.entierPourChaine");
        Scanner lecteur = new Scanner(System.in);
        Categorie environnementSciences = new Categorie("environnement-science");
        environnementSciences.initLexique("environnement-sciences.txt");
        System.out.print("Saisir un mot présent dans la catégorie environnement-science: ");
        String chaine = lecteur.nextLine();
        System.out.println("Valeur de la chaine " + chaine + " : " + UtilitairePaireChaineEntier.entierPourChaine(environnementSciences.getLexique(), chaine));
    }
    public static void question3() {
        System.out.println("Test méthode Categorie.score");
        Categorie environnementSciences = new Categorie("environnement-science");
        environnementSciences.initLexique("environnement-sciences.txt");
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./depeches.txt");
        int i = 0;
        while (i < 5) {
            System.out.println("Score de la dépêche n° " + depeches.get(i).getId() + " : " + environnementSciences.score(depeches.get(i)));
            i++;
        }
    }

    public static void question4() {
        System.out.println("Test méthode UtilitairePaireChaineEntier.chaineMax()");
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./depeches.txt");
        ArrayList<Categorie> Categorie = new ArrayList<>(Arrays.asList(
                new Categorie("ENVIRONNEMENT-SCIENCES"),
                new Categorie("CULTURE"),
                new Categorie("ECONOMIE"),
                new Categorie("POLITIQUE"),
                new Categorie("SPORTS")));
        Categorie.get(0).initLexique("environnement-sciences.txt");
        Categorie.get(1).initLexique("culture.txt");
        Categorie.get(2).initLexique("economie.txt");
        Categorie.get(3).initLexique("politique.txt");
        Categorie.get(4).initLexique("sport.txt");
        int i = 0;
        ArrayList<PaireChaineEntier> VScore = new ArrayList<>();
        while (i < Categorie.size()) {
            VScore.add(new PaireChaineEntier(Categorie.get(i).getNom(), Categorie.get(i).score(depeches.get(0))));
            i++;
        }
        i = 0;
        while (i < VScore.size()) {
            System.out.println(VScore.get(i).getChaine() + " : " + VScore.get(i).getEntier());
            i++;
        }
        System.out.println("Catégorie ayant le meilleur score: " + UtilitairePaireChaineEntier.chaineMax(VScore));
    }
    public static void question5() {
        System.out.println("Test méthode Classification.classementDepeche()");
        long startTime = System.currentTimeMillis();
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./depeches.txt");
        ArrayList<Categorie> categories = new ArrayList<>(Arrays.asList(
                new Categorie("ENVIRONNEMENT-SCIENCES"),
                new Categorie("CULTURE"),
                new Categorie("ECONOMIE"),
                new Categorie("POLITIQUE"),
                new Categorie("SPORTS")));
        categories.get(0).initLexique("environnement-sciences.txt");
        categories.get(1).initLexique("culture.txt");
        categories.get(2).initLexique("economie.txt");
        categories.get(3).initLexique("politique.txt");
        categories.get(4).initLexique("sport.txt");
        Classification.classementDepeches(depeches, categories, "Expériences/menu/testClassementDepeche.txt");
        long endTime = System.currentTimeMillis();
        System.out.println("Test effectué avec succès en " + (endTime - startTime) + " ms !");
    }

    public static void question6() {
        System.out.println("Test méthode Classification.generationLexique()");
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./depeches.txt");
        Classification.generationLexique(depeches, "ENVIRONNEMENT-SCIENCES", "Expériences/menu/environnement-sciences.txt");
        Classification.generationLexique(depeches, "CULTURE", "Expériences/menu/culture.txt");
        Classification.generationLexique(depeches, "ECONOMIE", "Expériences/menu/economie.txt");
        Classification.generationLexique(depeches, "POLITIQUE", "Expériences/menu/politique.txt");
        Classification.generationLexique(depeches, "SPORTS", "Expériences/menu/sports.txt");
        System.out.println("Test effectué avec succès !");
    }

    public static void question7() {
        System.out.println("Test programme entier (fichier depeches.txt)");
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./depeches.txt");
        ArrayList<Categorie> Categorie = new ArrayList<>(Arrays.asList(
                new Categorie("ENVIRONNEMENT-SCIENCES"),
                new Categorie("CULTURE"),
                new Categorie("ECONOMIE"),
                new Categorie("POLITIQUE"),
                new Categorie("SPORTS")));
        Classification.generationLexique(depeches, "ENVIRONNEMENT-SCIENCES", "Expériences/menu/environnement-sciences.txt");
        Classification.generationLexique(depeches, "CULTURE", "Expériences/menu/culture.txt");
        Classification.generationLexique(depeches, "ECONOMIE", "Expériences/menu/economie.txt");
        Classification.generationLexique(depeches, "POLITIQUE", "Expériences/menu/politique.txt");
        Classification.generationLexique(depeches, "SPORTS", "Expériences/menu/sports.txt");
        Categorie.get(0).initLexique("Expériences/menu/environnement-sciences.txt");
        Categorie.get(1).initLexique("Expériences/menu/culture.txt");
        Categorie.get(2).initLexique("Expériences/menu/economie.txt");
        Categorie.get(3).initLexique("Expériences/menu/politique.txt");
        Categorie.get(4).initLexique("Expériences/menu/sports.txt");
        Classification.classementDepeches(depeches, Categorie, "Expériences/menu/resultat.txt");
        System.out.println("Test effectué avec succès !");
    }
    public static void question8() {
        System.out.println("Test fonction de transformation de fichier XML pour la prise en charge de notre programme");
        TestXML.rss("Expériences/Exp 6 RSS/foot.txt", "Expériences/menu/fichierRSS.txt");
        System.out.println("Test effectué avec succès !");

    }

    public static void question9() {
        // Test avec amélioration
        long startTime = System.currentTimeMillis();
        long startTimeGenLexique = System.currentTimeMillis();
        ArrayList<Depeche> depeches = Classification.lectureDepeches("./test.txt");
        Tri.generationLexiqueTrie(depeches, "ENVIRONNEMENT-SCIENCES", "Expériences/menu/avec amelioration/lexique-sciences.txt");
        Tri.generationLexiqueTrie(depeches, "CULTURE", "Expériences/menu/avec amelioration/lexique-cultures.txt");
        Tri.generationLexiqueTrie(depeches, "ECONOMIE", "Expériences/menu/avec amelioration/lexique-economie.txt");
        Tri.generationLexiqueTrie(depeches, "POLITIQUE", "Expériences/menu/avec amelioration/lexique-politique.txt");
        Tri.generationLexiqueTrie(depeches, "SPORTS", "Expériences/menu/avec amelioration/lexique-sports.txt");
        long endTimeGenLexique = System.currentTimeMillis();
        long startTimeClassiffication = System.currentTimeMillis();
        ArrayList<Categorie> categories = new ArrayList<>(Arrays.asList(
                new Categorie("ENVIRONNEMENT-SCIENCES", "Expériences/menu/avec amelioration/lexique-sciences.txt"),
                new Categorie("CULTURE", "Expériences/menu/avec amelioration/lexique-cultures.txt"),
                new Categorie("ECONOMIE", "Expériences/menu/avec amelioration/lexique-economie.txt"),
                new Categorie("POLITIQUE", "Expériences/menu/avec amelioration/lexique-politique.txt"),
                new Categorie("SPORTS", "Expériences/menu/avec amelioration/lexique-sports.txt")
        ));
        Tri.classementDepechesTrie(depeches, categories, "Expériences/menu/avec amelioration/resultat.txt");
        long endTimeClassiffication = System.currentTimeMillis();
        long endTime = System.currentTimeMillis();
        System.out.println("Temps d'exécution du programme AVEC amélioration du temps de traitement:\n" +
                " - pour la génération de lexique: " + (endTimeGenLexique - startTimeGenLexique) + " ms\n" +
                " - pour la classiffication des dépêches: " + (endTimeClassiffication - startTimeClassiffication) + " ms\n" +
                " - du programme total: " + (endTime - startTime) + " ms\n");


        // Test sans amélioration
        startTime = System.currentTimeMillis();
        startTimeGenLexique = System.currentTimeMillis();
        ArrayList<Depeche> depeches2 = Classification.lectureDepeches("./test.txt");
        Classification.generationLexique(depeches, "ENVIRONNEMENT-SCIENCES", "Expériences/menu/sans amelioration/lexique-sciences.txt");
        Classification.generationLexique(depeches, "CULTURE", "Expériences/menu/sans amelioration/lexique-cultures.txt");
        Classification.generationLexique(depeches, "ECONOMIE", "Expériences/menu/sans amelioration/lexique-economie.txt");
        Classification.generationLexique(depeches, "POLITIQUE", "Expériences/menu/sans amelioration/lexique-politique.txt");
        Classification.generationLexique(depeches, "SPORTS", "Expériences/menu/sans amelioration/lexique-sports.txt");
        endTimeGenLexique = System.currentTimeMillis();
        startTimeClassiffication = System.currentTimeMillis();
        ArrayList<Categorie> categories2 = new ArrayList<>(Arrays.asList(
                new Categorie("ENVIRONNEMENT-SCIENCES", "Expériences/menu/sans amelioration/lexique-sciences.txt"),
                new Categorie("CULTURE", "Expériences/menu/sans amelioration/lexique-cultures.txt"),
                new Categorie("ECONOMIE", "Expériences/menu/sans amelioration/lexique-economie.txt"),
                new Categorie("POLITIQUE", "Expériences/menu/sans amelioration/lexique-politique.txt"),
                new Categorie("SPORTS", "Expériences/menu/sans amelioration/lexique-sports.txt")
        ));
        Classification.classementDepeches(depeches2, categories2, "Expériences/menu/sans amelioration/resultat.txt");
        endTimeClassiffication = System.currentTimeMillis();
        endTime = System.currentTimeMillis();
        System.out.println("Temps d'exécution du programme SANS amélioration du temps de traitement:\n" +
                " - pour la génération de lexique: " + (endTimeGenLexique - startTimeGenLexique) + " ms\n" +
                " - pour la classiffication des dépêches: " + (endTimeClassiffication - startTimeClassiffication) + " ms\n" +
                " - du programme total: " + (endTime - startTime) + " ms\n");
    }
}
