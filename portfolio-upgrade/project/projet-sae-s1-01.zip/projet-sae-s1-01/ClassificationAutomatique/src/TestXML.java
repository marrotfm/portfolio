import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static java.lang.Integer.valueOf;

public class TestXML {
    public static void rss(String nomFichier, String nouveauFichier) {
        try {
            FileInputStream fichierxml = new FileInputStream(nomFichier);
            Scanner scanner = new Scanner(fichierxml);
            FileWriter newFile = new FileWriter(nouveauFichier);
            int compteurDepeche = 0;
            String categorie = "categorie";
            String date = "";
            while (scanner.hasNextLine()) {
                String ligne = scanner.nextLine();
                if (ligne.contains("<title>")) {
                    String mots = ligne.substring(7, ligne.length()-8);
                    String mot[] = mots.split("-");
                    categorie = mot[1].substring(1, mot[1].length());
                } else if (ligne.contains("<pubDate>")) {
                    Pattern p = Pattern.compile("([0-9]{2}) ((Jan|Fév|Mar|Avr|Mai|Jun|Jul|Aoû|Sep|Oct|Nov|Déc)) ([0-9]{4})");
                    Matcher m = p.matcher(ligne);
                    if (m.find()) {
                        date = m.group(1);
                        date += switch (m.group(2)) {
                            case "Jan" -> "01";
                            case "Fév" -> "02";
                            case "Mar" -> "03";
                            case "Avr" -> "04";
                            case "Mai" -> "05";
                            case "Jun" -> "06";
                            case "Jul" -> "07";
                            case "Aoû" -> "08";
                            case "Sep" -> "09";
                            case "Oct" -> "10";
                            case "Nov" -> "11";
                            case "Déc" -> "12";
                            default -> date;
                        };
                        date += valueOf(m.group(4))%100 + "";
                    }
                } else if (ligne.contains("<item>")) {
                    compteurDepeche++;
                    String title = "titre";
                    String description = "description";
                    while (scanner.hasNextLine() && !ligne.contains("</item>")) {
                        ligne = scanner.nextLine();
                        if (ligne.contains("<title>")) {
                            ligne = scanner.nextLine();
                            title = ligne;
                        } else if (ligne.contains("<description>")) {
                            ligne = scanner.nextLine();
                            description = ligne;
                        }
                    }
                    newFile.write(
                            ".N " + compteurDepeche + "\n"
                            + ".D " + date + "\n"
                            + ".C " + categorie + "\n"
                            + ".T " + title + "\n"
                            + description + "\n\n"
                            );
                }
            }
            scanner.close();
            newFile.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

