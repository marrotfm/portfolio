import java.util.ArrayList;

public class UtilitairePaireChaineEntier {


    public static int indicePourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        int i = 0;
        while (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) != 0) {
            i++;
        }
        if (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) == 0) {
            return i;
        } else {
            return -1;
        }
    }

    public static int entierPourChaine(ArrayList<PaireChaineEntier> listePaires, String chaine) {
        // retourne l'entier associé à chaine si elle est présente dans listePaires, sinon 0
        int i = 0;
        while (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) != 0) {
            i++;
        }
        if (i < listePaires.size() && listePaires.get(i).getChaine().compareTo(chaine) == 0) {
            return listePaires.get(i).getEntier();
        } else {
            return 0;
        }
    }

    public static String chaineMax(ArrayList<PaireChaineEntier> listePaires) {
        int i = 0;
        int indiceMax = 0;
        int scoreMax = 0;
        while (i < listePaires.size()) {
            if (listePaires.get(i).getEntier() > scoreMax) {
                indiceMax = i;
                scoreMax = listePaires.get(i).getEntier();
            }
            i++;
        }
        return listePaires.get(indiceMax).getChaine();
    }


    public static float moyenne(ArrayList<PaireChaineEntier> listePaires) {
        float somme = 0;
        int i = 0;
        while (i < listePaires.size()) {
            somme+=listePaires.get(i).getEntier();
            i++;
        }
        return Math.round((somme/500)*100);
    }
}
